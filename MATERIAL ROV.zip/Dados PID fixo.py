import matplotlib.pyplot as plt

# Dados fornecidos
tempo = [722, 1644, 2543, 3442, 4340, 5238, 6138, 7035, 7934, 8834, 9731, 10630, 
         11529, 12428, 13326, 14224, 15123, 16021, 16918, 17818, 18716, 19615, 
         20513, 21412, 22310, 23208, 24108, 25006, 25905, 26803, 27702, 28600, 
         29498, 30397, 31294, 32193, 33091, 33990, 34888, 35788, 36686, 37584, 
         38483, 39382, 40280, 41179, 42079, 42975, 43875, 44772]
profundidade = [0.57, 0.65, 2.32, 6.74, 12.16, 17.54, 20.44, 23.49, 24.73, 23.96, 
                22.27, 21.06, 20.18, 19.66, 19.34, 19.74, 21.66, 22.47, 22.40, 
                22.02, 21.28, 20.85, 20.80, 20.81, 20.85, 20.92, 20.92, 20.90, 
                20.89, 20.87, 20.88, 20.90, 20.90, 20.89, 20.88, 20.86, 20.86, 
                20.87, 20.87, 20.85, 20.54, 20.00, 19.86, 19.94, 20.28, 20.59, 
                20.48, 20.11, 19.99, 20.02]
setpoint = [20] * len(tempo)  # Constante de 20 cm para o setpoint
valor_controle = [255.00, 255.00, 255.00, 181.46, 68.45, -10.64, 21.91, -38.22, -12.69, 
                  50.53, 98.46, 98.69, 101.10, 99.11, 98.80, 71.60, -9.44, 6.56, 
                  28.70, 38.46, 57.13, 51.93, 38.28, 34.60, 30.48, 26.04, 25.95, 
                  24.30, 21.82, 19.85, 16.71, 13.60, 11.80, 9.55, 7.60, 5.74, 
                  2.89, 0.20, -2.18, -3.40, 9.07, 24.03, 14.34, 6.21, -7.58, 
                  -13.10, 0.51, 13.73, 8.12, 2.64]

# Convertendo tempo para segundos
tempo_segundos = [t / 1000 for t in tempo]

# Criando o gráfico
fig, ax1 = plt.subplots(figsize=(10, 6))

# Plotando valor de controle no eixo y principal (esquerdo)
ax1.plot(tempo_segundos, valor_controle, label='Valor de Controle', color='blue', linewidth=2)
ax1.set_xlabel('Tempo (s)', fontsize=14, fontweight='bold')
ax1.set_ylabel('Valor PWM de Controle', fontsize=14, fontweight='bold')
ax1.tick_params(axis='y', labelsize=12, width=2)
ax1.tick_params(axis='x', labelsize=12, width=2)

# Criando um eixo y secundário para profundidade e setpoint
ax2 = ax1.twinx()
ax2.plot(tempo_segundos, profundidade, label='Profundidade', color='red', linewidth=3)
ax2.plot(tempo_segundos, setpoint, label='Setpoint', color='black', linewidth=3)
ax2.set_ylabel('Profundidade (cm)', fontsize=14, fontweight='bold')
ax2.tick_params(axis='y', labelsize=12, width=2)

# Ajustando a legenda
fig.tight_layout()
lines_1, labels_1 = ax1.get_legend_handles_labels()
lines_2, labels_2 = ax2.get_legend_handles_labels()
ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper right', prop={'size': 12, 'weight': 'bold'})

# Adicionando grid
ax1.grid(True)

# Configurando negrito para os índices
plt.xticks(fontsize=12, fontweight='bold')
plt.yticks(fontsize=12, fontweight='bold')
ax2.tick_params(axis='y', labelsize=12, width=2)

plt.show()
